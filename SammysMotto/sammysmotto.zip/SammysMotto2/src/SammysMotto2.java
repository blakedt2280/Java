import javax.swing.*;

public class SammysMotto2 {
    public static void main(String[] args) {


        JOptionPane.showMessageDialog(null, "ssssssssssssssssssssssssssssssss\ns Sammy's makes it fun in the sun  s \n sssssssssssssssssssssssssssssss");

    }
}
