import javax.swing.*;

public class SammysMotto {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Sammy's makes it fun in the sun"
        );
    }
}

